
From the cli run:
		
		-> make

Then:

		-> smallsh	

And if you want:
	
		-> make clean && make
